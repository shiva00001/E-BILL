
import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:number_to_words/number_to_words.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:pdf/pdf.dart';
import 'package:printing/printing.dart';
import 'package:share_plus/share_plus.dart';
import 'dart:io';
import 'package:path_provider/path_provider.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final dir = await getApplicationDocumentsDirectory();
  Hive.init(dir.path);
  await Hive.openBox('bills');
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'E-BILL Generator',
      theme: ThemeData(primarySwatch: Colors.blue),
      home: BillFormScreen(),
    );
  }
}

class BillFormScreen extends StatefulWidget {
  @override
  _BillFormScreenState createState() => _BillFormScreenState();
}

class _BillFormScreenState extends State<BillFormScreen> {
  final _formKey = GlobalKey<FormState>();
  final Map<String, TextEditingController> controllers = {
    'billNo': TextEditingController(),
    'date': TextEditingController(),
    'bookingStn': TextEditingController(),
    'consignmentNo': TextEditingController(),
    'consignmentDate': TextEditingController(),
    'destCode': TextEditingController(),
    'particulars': TextEditingController(),
    'weight': TextEditingController(),
    'rate': TextEditingController(),
    'amount': TextEditingController(),
  };

  Future<Uint8List> generatePdf(Map<String, String> data) async {
    final pdf = pw.Document();
    final int amountInt = int.tryParse(data['amount']!.replaceAll(RegExp(r'[^0-9]'), '')) ?? 0;
    String amountInWords = NumberToWord().convert('en-in', amountInt);
    amountInWords = "${amountInWords[0].toUpperCase()}${amountInWords.substring(1)} only";

    pdf.addPage(pw.Page(
      pageFormat: PdfPageFormat.a4,
      build: (pw.Context context) {
        return pw.Padding(
          padding: pw.EdgeInsets.all(20),
          child: pw.Column(
            crossAxisAlignment: pw.CrossAxisAlignment.start,
            children: [
              pw.Text("E-BILL", style: pw.TextStyle(fontSize: 24, fontWeight: pw.FontWeight.bold)),
              pw.SizedBox(height: 10),
              pw.Text("Bill No: ${data['billNo']}    Date: ${data['date']}", style: pw.TextStyle(fontSize: 14)),
              pw.Text("Booking Stn: ${data['bookingStn']}", style: pw.TextStyle(fontSize: 14)),
              pw.Text("Consignment No: ${data['consignmentNo']}    Date: ${data['consignmentDate']}    Destn Code: ${data['destCode']}", style: pw.TextStyle(fontSize: 14)),
              pw.SizedBox(height: 10),
              pw.Text("Particulars:", style: pw.TextStyle(fontSize: 14)),
              pw.Text(data['particulars'] ?? '', style: pw.TextStyle(fontSize: 12)),
              pw.SizedBox(height: 10),
              pw.Text("Weight: ${data['weight']}    Rate/Ton: ${data['rate']}", style: pw.TextStyle(fontSize: 14)),
              pw.Text("Amount: Rs. ${data['amount']}", style: pw.TextStyle(fontSize: 14)),
              pw.Text("Total in Words: Rs. $amountInWords", style: pw.TextStyle(fontSize: 14)),
            ],
          ),
        );
      },
    ));

    return pdf.save();
  }

  Future<void> saveAndShare(Map<String, String> data) async {
    final pdfBytes = await generatePdf(data);
    final dir = await getApplicationDocumentsDirectory();
    final file = File('${dir.path}/${data['billNo']}.pdf');
    await file.writeAsBytes(pdfBytes);

    final box = Hive.box('bills');
    await box.add(data);

    await Share.shareXFiles([XFile(file.path)], text: 'Here is your E-BILL PDF.');
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('E-BILL Generator')),
      body: Padding(
        padding: const EdgeInsets.all(12.0),
        child: Form(
          key: _formKey,
          child: SingleChildScrollView(
            child: Column(
              children: [
                ...controllers.entries.map((entry) => Padding(
                      padding: const EdgeInsets.symmetric(vertical: 6),
                      child: TextFormField(
                        controller: entry.value,
                        decoration: InputDecoration(
                          labelText: entry.key,
                          border: OutlineInputBorder(),
                        ),
                        keyboardType: entry.key == 'amount' || entry.key == 'weight' || entry.key == 'rate'
                            ? TextInputType.number
                            : TextInputType.text,
                      ),
                    )),
                SizedBox(height: 20),
                ElevatedButton(
                  onPressed: () {
                    final data = controllers.map((key, value) => MapEntry(key, value.text));
                    saveAndShare(data);
                  },
                  child: Text('Generate & Share'),
                )
              ],
            ),
          ),
        ),
      ),
    );
  }
}
